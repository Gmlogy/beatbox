
import React, { createContext, useState, useContext, useEffect, useRef } from 'react';
import { logPlay } from '@/api/functions';

const PlayerContext = createContext();

export const usePlayer = () => useContext(PlayerContext);

export const PlayerProvider = ({ children }) => {
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(75);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState('off'); // off, all, one
  const [playlist, setPlaylist] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlayerMinimized, setIsPlayerMinimized] = useState(false);
  
  // Audio element ref for actual playback
  const audioRef = useRef(new Audio());
  const playPromiseRef = useRef(null);
  const playbackStartTimeRef = useRef(null); // To track when playback started for logging
  const currentTrackRef = useRef(null); // To hold the current track for logging in callbacks

  // Update currentTrackRef whenever currentTrack state changes
  useEffect(() => {
    currentTrackRef.current = currentTrack;
  }, [currentTrack]);
  
  // Helper function to log playback duration
  const handlePlaybackStop = (wasSkipped = false) => {
    if (playbackStartTimeRef.current && currentTrackRef.current) {
      const durationPlayed = (Date.now() - playbackStartTimeRef.current) / 1000;
      // Log if played for more than 5 seconds
      if (durationPlayed > 5) {
        logPlay({
          trackId: currentTrackRef.current.id,
          durationPlayed: Math.round(durationPlayed),
          wasSkipped
        });
      }
    }
    playbackStartTimeRef.current = null; // Reset for the next playback
  };

  useEffect(() => {
    const audio = audioRef.current;
    
    const updateTime = () => setCurrentTime(audio.currentTime);
    const handleEnded = () => {
      handlePlaybackStop(false); // Playback ended naturally, not skipped
      if (repeatMode === 'one') {
        audio.currentTime = 0;
        safePlay();
      } else if (repeatMode === 'all' || currentIndex < playlist.length - 1) {
        playNext();
      } else {
        setIsPlaying(false);
      }
    };
    const handleLoadedMetadata = () => {
      if (isPlaying) {
        safePlay();
      }
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    
    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [isPlaying, repeatMode, currentIndex, playlist]);

  useEffect(() => {
    const audio = audioRef.current;
    audio.volume = isMuted ? 0 : volume / 100;
  }, [volume, isMuted]);

  useEffect(() => {
    const audio = audioRef.current;
    if (currentTrack) {
      // Always pause and reset before switching tracks
      audio.pause();
      setCurrentTime(0);
      
      // In a real app, this would be a web-accessible file URL.
      // For this demo, we use a public placeholder audio file to ensure playback works,
      // as browser security prevents access to local file paths like "/Music/...".
      audio.src = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
      audio.load(); // Explicitly load the new source
      
      // Start playing if we should be playing
      if (isPlaying) {
        audio.currentTime = 0;
        safePlay();
      }
    }
  }, [currentTrack]);

  const safePlay = async () => {
    const audio = audioRef.current;
    
    // Cancel any existing play promise
    if (playPromiseRef.current) {
      try {
        await playPromiseRef.current;
      } catch (error) {
        // Ignore interrupted play errors
      }
    }
    
    try {
      playPromiseRef.current = audio.play();
      await playPromiseRef.current;
      playPromiseRef.current = null;
      // Record playback start time only if it's a new play, not a resume
      if (!playbackStartTimeRef.current) {
          playbackStartTimeRef.current = Date.now();
      }
    } catch (error) {
      playPromiseRef.current = null;
      if (error.name !== 'AbortError' && error.name !== 'NotAllowedError') {
        console.error('Audio play error:', error);
      }
    }
  };

  const safePause = async () => {
    const audio = audioRef.current;
    
    // Wait for any pending play promise to resolve
    if (playPromiseRef.current) {
      try {
        await playPromiseRef.current;
        playPromiseRef.current = null;
      } catch (error) {
        // Ignore errors when interrupting play
        playPromiseRef.current = null;
      }
    }
    
    handlePlaybackStop(true); // Playback paused/skipped
    audio.pause();
  };

  const play = async (track, trackList = null) => {
    // If a track is currently playing and a new one is requested, log the current one as skipped
    if (isPlaying) {
      handlePlaybackStop(true);
    }
    await safePause();
    
    if (track && track.id !== currentTrack?.id) {
      setCurrentTrack(track);
      setCurrentTime(0);
      if (trackList) {
        setPlaylist(trackList);
        setCurrentIndex(trackList.findIndex(t => t.id === track.id));
      }
    }
    setIsPlaying(true);
  };

  const pause = async () => {
    setIsPlaying(false);
    await safePause();
  };

  const seek = (time) => {
    const audio = audioRef.current;
    audio.currentTime = time;
    setCurrentTime(time);
  };

  const playNext = () => {
    handlePlaybackStop(true); // Current track is being skipped
    if (playlist.length === 0) return;
    
    let nextIndex;
    if (isShuffled) {
      nextIndex = Math.floor(Math.random() * playlist.length);
    } else {
      nextIndex = currentIndex + 1;
      if (nextIndex >= playlist.length) {
        if (repeatMode === 'all') {
          nextIndex = 0;
        } else {
          setIsPlaying(false);
          return;
        }
      }
    }
    
    setCurrentIndex(nextIndex);
    const nextTrack = playlist[nextIndex];
    setCurrentTrack(nextTrack);
    setCurrentTime(0);
  };

  const playPrevious = () => {
    handlePlaybackStop(true); // Current track is being skipped
    if (playlist.length === 0) return;
    
    let prevIndex = currentIndex - 1;
    if (prevIndex < 0) {
      prevIndex = playlist.length - 1;
    }
    
    setCurrentIndex(prevIndex);
    const prevTrack = playlist[prevIndex];
    setCurrentTrack(prevTrack);
    setCurrentTime(0);
  };

  const toggleShuffle = () => {
    setIsShuffled(!isShuffled);
  };

  const toggleRepeat = () => {
    const modes = ['off', 'all', 'one'];
    const currentModeIndex = modes.indexOf(repeatMode);
    setRepeatMode(modes[(currentModeIndex + 1) % modes.length]);
  };

  const togglePlayerSize = () => {
    setIsPlayerMinimized(prev => !prev);
  };

  const setVolumeLevel = (newVolume) => {
    setVolume(newVolume);
    setIsMuted(false);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const value = {
    currentTrack,
    isPlaying,
    currentTime,
    volume,
    isMuted,
    isShuffled,
    repeatMode,
    playlist,
    currentIndex,
    isPlayerMinimized,
    play,
    pause,
    seek,
    playNext,
    playPrevious,
    toggleShuffle,
    toggleRepeat,
    setVolumeLevel,
    toggleMute,
    togglePlayerSize,
  };

  return (
    <PlayerContext.Provider value={value}>
      {children}
    </PlayerContext.Provider>
  );
};
