import React, { useState } from "react";
import { Track } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { extractTrackMetadata } from "@/api/functions";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  FolderOpen, 
  Music, 
  CheckCircle, 
  AlertCircle,
  X,
  FileUp,
  Loader2
} from "lucide-react";

export default function ImportDialog({ open, onOpenChange, onImportComplete }) {
  const [status, setStatus] = useState('idle'); // idle, uploading, processing, success, error
  const [progress, setProgress] = useState(0);
  const [processedCount, setProcessedCount] = useState(0);
  const [totalFiles, setTotalFiles] = useState(0);
  const [errorDetails, setErrorDetails] = useState("");
  
  const processFiles = async (files) => {
    setStatus('uploading');
    setTotalFiles(files.length);
    setProcessedCount(0);
    setProgress(0);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        // 1. Upload the file
        setProgress((i / files.length) * 33); // Uploading is ~1/3 of the process
        const { file_url } = await UploadFile({ file });
        
        // 2. Process metadata
        setStatus('processing');
        setProgress(33 + (i / files.length) * 33); // Processing is the next 1/3
        const { data: trackData, error: metadataError } = await extractTrackMetadata({ file_url });
        
        if (metadataError) {
          throw new Error(`Metadata extraction failed: ${metadataError.error}`);
        }

        // 3. Create track in database
        setProgress(66 + (i / files.length) * 34); // DB insert is the final 1/3
        await Track.create(trackData);

        setProcessedCount(i + 1);

      } catch (error) {
        console.error(`Failed to import ${file.name}:`, error);
        setErrorDetails(`Error with ${file.name}: ${error.message}`);
        setStatus('error');
        return; // Stop on first error
      }
    }

    setStatus('success');
    setTimeout(() => {
      onImportComplete();
      onOpenChange(false);
      resetState();
    }, 2000);
  };

  const handleFileSelect = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = 'audio/*,.mp3,.aac,.flac,.alac,.aiff,.wav';
    
    input.onchange = (e) => {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        processFiles(files);
      }
      document.body.removeChild(input);
    };
    
    document.body.appendChild(input);
    input.click();
  };
  
  const resetState = () => {
    setStatus('idle');
    setProgress(0);
    setProcessedCount(0);
    setTotalFiles(0);
    setErrorDetails("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Music className="w-5 h-5" />
            Import Music Files
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 min-h-[300px] flex flex-col justify-center">
          {status === 'idle' && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileUp className="w-8 h-8 text-slate-600 dark:text-slate-400" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">Add Music to Your Library</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                Click below to select audio files from your computer.
              </p>
              <Button 
                onClick={handleFileSelect}
                className="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-800 hover:from-slate-800 hover:via-blue-800 hover:to-slate-700 ripple-effect text-white"
              >
                <Upload className="w-4 h-4 mr-2" />
                Browse Files
              </Button>
            </div>
          )}

          {(status === 'uploading' || status === 'processing') && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
                {status === 'uploading' ? 'Uploading Files...' : 'Processing Metadata...'}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                Please wait while we process your music.
              </p>
              
              <div className="space-y-3">
                <Progress value={progress} className="h-2" />
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {processedCount} of {totalFiles} tracks imported
                </p>
              </div>
            </div>
          )}

          {status === 'success' && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">Import Complete!</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Successfully imported {processedCount} tracks to your library.
              </p>
            </div>
          )}

          {status === 'error' && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">Import Failed</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 break-words">
                {errorDetails}
              </p>
              <Button 
                variant="outline" 
                onClick={resetState}
                className="ripple-effect dark:bg-slate-700 dark:border-slate-600 dark:hover:bg-slate-600 dark:text-slate-100"
              >
                Try Again
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}