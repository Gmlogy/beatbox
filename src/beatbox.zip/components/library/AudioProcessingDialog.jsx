import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { processAudioFiles } from '@/api/functions';
import { Settings, Zap, Volume2, FileAudio, Loader2 } from 'lucide-react';

const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default function AudioProcessingDialog({ open, onOpenChange, selectedTracks }) {
    const [operation, setOperation] = useState('transcode');
    const [targetFormat, setTargetFormat] = useState('MP3');
    const [processing, setProcessing] = useState(false);
    const [results, setResults] = useState(null);
    const [progress, setProgress] = useState(0);

    const handleProcess = async () => {
        if (!selectedTracks || selectedTracks.length === 0) return;
        
        setProcessing(true);
        setResults(null);
        setProgress(0);
        
        try {
            const { data } = await processAudioFiles({
                operation,
                trackIds: selectedTracks.map(t => t.id),
                targetFormat: operation === 'transcode' ? targetFormat : undefined,
                normalizeVolume: operation === 'normalize'
            });
            
            setResults(data);
            setProgress(100);
        } catch (error) {
            console.error("Processing error:", error);
            alert("An error occurred during processing.");
        }
        
        setProcessing(false);
    };

    const reset = () => {
        setResults(null);
        setProgress(0);
        setProcessing(false);
    };

    return (
        <Dialog open={open} onOpenChange={(open) => { onOpenChange(open); if (!open) reset(); }}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Settings className="w-5 h-5 text-blue-600" />
                        Audio Processing
                    </DialogTitle>
                </DialogHeader>
                
                {!results ? (
                    <div className="space-y-6">
                        <div className="text-sm text-slate-600 dark:text-slate-400">
                            Process {selectedTracks?.length || 0} selected track{selectedTracks?.length !== 1 ? 's' : ''}
                        </div>
                        
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="operation">Processing Operation</Label>
                                <Select value={operation} onValueChange={setOperation}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="transcode">
                                            <div className="flex items-center gap-2">
                                                <FileAudio className="w-4 h-4" />
                                                Format Conversion
                                            </div>
                                        </SelectItem>
                                        <SelectItem value="normalize">
                                            <div className="flex items-center gap-2">
                                                <Volume2 className="w-4 h-4" />
                                                Volume Normalization
                                            </div>
                                        </SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            {operation === 'transcode' && (
                                <div>
                                    <Label htmlFor="targetFormat">Target Format</Label>
                                    <Select value={targetFormat} onValueChange={setTargetFormat}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="MP3">MP3 (Most Compatible)</SelectItem>
                                            <SelectItem value="AAC">AAC (High Quality)</SelectItem>
                                            <SelectItem value="OGG">OGG (Open Source)</SelectItem>
                                            <SelectItem value="FLAC">FLAC (Lossless)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            )}
                            
                            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                                <div className="flex items-start gap-3">
                                    <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                                    <div className="text-sm">
                                        <div className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                                            {operation === 'transcode' ? 'Format Conversion' : 'Volume Normalization'}
                                        </div>
                                        <div className="text-blue-700 dark:text-blue-300">
                                            {operation === 'transcode' 
                                                ? `Convert selected tracks to ${targetFormat} format. This may reduce file sizes and improve compatibility.`
                                                : 'Analyze and adjust volume levels to ensure consistent playback across all tracks.'
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        {processing && (
                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    <span className="text-sm">Processing audio files...</span>
                                </div>
                                <Progress value={progress} className="w-full" />
                            </div>
                        )}
                        
                        <div className="flex justify-end gap-3">
                            <Button variant="outline" onClick={() => onOpenChange(false)}>
                                Cancel
                            </Button>
                            <Button 
                                onClick={handleProcess} 
                                disabled={processing || !selectedTracks || selectedTracks.length === 0}
                            >
                                {processing ? "Processing..." : `Process ${selectedTracks?.length || 0} Track${selectedTracks?.length !== 1 ? 's' : ''}`}
                            </Button>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-6">
                        <div className="text-center">
                            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Settings className="w-8 h-8 text-green-600 dark:text-green-400" />
                            </div>
                            <h3 className="text-lg font-semibold mb-2">Processing Complete</h3>
                            <p className="text-slate-600 dark:text-slate-400">
                                {results.processed} tracks processed successfully
                                {results.failed > 0 && `, ${results.failed} failed`}
                            </p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-center">
                                <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                                    {results.processed}
                                </div>
                                <div className="text-xs text-slate-600 dark:text-slate-400">Processed</div>
                            </div>
                            {operation === 'transcode' && results.totalSpaceSaved > 0 && (
                                <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg text-center">
                                    <div className="text-2xl font-bold text-green-700 dark:text-green-400">
                                        {formatBytes(results.totalSpaceSaved)}
                                    </div>
                                    <div className="text-xs text-green-600 dark:text-green-500">Space Saved</div>
                                </div>
                            )}
                            {operation === 'normalize' && (
                                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg text-center">
                                    <div className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                                        {results.totalProcessingTimeSeconds}s
                                    </div>
                                    <div className="text-xs text-blue-600 dark:text-blue-500">Processing Time</div>
                                </div>
                            )}
                        </div>
                        
                        <div className="flex justify-end">
                            <Button onClick={() => onOpenChange(false)}>
                                Done
                            </Button>
                        </div>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}